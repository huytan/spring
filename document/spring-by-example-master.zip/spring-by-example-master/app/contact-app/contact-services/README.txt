Contact Services

This project can be built using Maven (http://maven.apache.org).  It can also be imported into 
the Eclipse IDE, but the M2Eclipse plugin should be installed since it is used to resolve 
the classpath.


Release Notes
--------------
1.1.1 - Upgraded to Spring 4.0.2.

1.1 -   Updated to use shared Spring by Example REST libraries.

1.0 -	Initial release.
