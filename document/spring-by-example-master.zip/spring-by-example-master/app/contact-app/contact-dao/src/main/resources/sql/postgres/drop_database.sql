 drop database contact;
 drop user contact;
