Contact Webapp

This project can be built using Maven (http://maven.apache.org).  It can also be imported into 
the Eclipse IDE, but the M2Eclipse plugin should be installed since it is used to resolve 
the classpath.

It can also be run from the command line with 'mvn jetty:run'.

NOTE: Sencha Touch has a commercial and open source licensing model.  The open source model is 
	  under GPLv3, but is compatible with other open source licenses like Apache.  
	  Please refer to their licensing based on your project requirements
	  
        http://www.sencha.com/products/touch/license/


Release Notes
--------------
1.1.1 - Upgraded to Spring 4.0.2.

1.1 -   Updated to use shared Spring by Example REST libraries.

1.0 -	Initial release.
